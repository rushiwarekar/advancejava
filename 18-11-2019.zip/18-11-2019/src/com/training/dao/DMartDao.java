package com.training.dao;

import java.util.List;

import com.training.beans.Category;

public interface DMartDao {

	boolean validateUser(String username, String password);

	int updatePassword(String username, String password);

	List<Category> getCategory();

}
