package com.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.training.beans.Category;

public class DMartDaoImpl implements DMartDao{

	List<Category> clist = new ArrayList<>();
	static Connection conn=null;
	static PreparedStatement pselectLogin=null;
	static PreparedStatement pupdatepass=null;
	static PreparedStatement pselectCat=null;
	static {
		conn=MyConnection.getMyConnection();
		try {
			pselectLogin = conn.prepareStatement("select name,password from users where name=? && password=?");
			pupdatepass = conn.prepareStatement("update users set password=? where name=?");
			pselectCat = conn.prepareStatement("select * from category");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean validateUser(String username, String password) {
		try {
			pselectLogin.setString(1, username);
			pselectLogin.setString(2, password);
			
			ResultSet rs=pselectLogin.executeQuery();
			
			if(rs.next())
			{
				if(rs.getString(1).equals(username) && rs.getString(2).equals(password))
				{
					return true;
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public int updatePassword(String username, String password) {
	
		try {
			pupdatepass.setString(1, password);
			pupdatepass.setString(2, username);
			
			return pupdatepass.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<Category> getCategory() {
		try {
			ResultSet rs = pselectCat.executeQuery();
			while(rs.next())
			{
				Category c = new Category(rs.getInt(1), rs.getString(2));
				clist.add(c);
			}
			return clist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
