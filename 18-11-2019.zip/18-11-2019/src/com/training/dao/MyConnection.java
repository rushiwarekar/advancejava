package com.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
	static Connection conn=null;
	public static Connection getMyConnection()
	{
		if(conn==null)
		{
			try {
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				String url="jdbc:mysql://192.168.10.71:3307/dac94";
				String username="dac94";
				String password="welcome";
				conn=DriverManager.getConnection(url,username,password);
				if(conn!=null)
				{
					System.out.println("connection Done...");
				}
				else
				{
					System.out.println("connection not Done....");
				}
				return conn;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
}
