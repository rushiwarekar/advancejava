package com.training.service;

import java.util.List;

import com.training.beans.Category;

public interface DMartService {

	boolean validateUser(String username, String password);

	int updatePassword(String username, String password);

	List<Category> getCategory();

}
