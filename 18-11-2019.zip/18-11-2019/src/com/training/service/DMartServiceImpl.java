package com.training.service;

import java.util.List;

import com.training.beans.Category;
import com.training.dao.DMartDao;
import com.training.dao.DMartDaoImpl;

public class DMartServiceImpl implements DMartService{
	
	DMartDao dmartdao=null;
	
	public DMartServiceImpl() {
		dmartdao = new DMartDaoImpl();
	}

	@Override
	public boolean validateUser(String username, String password) {
		return dmartdao.validateUser(username,password);
	}

	@Override
	public int updatePassword(String username, String password) {
		return dmartdao.updatePassword(username,password);
	}

	@Override
	public List<Category> getCategory() {
		return dmartdao.getCategory();
	}

}
