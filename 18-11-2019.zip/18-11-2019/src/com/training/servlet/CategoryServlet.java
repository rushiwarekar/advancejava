package com.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.training.beans.Category;
import com.training.service.DMartService;
import com.training.service.DMartServiceImpl;

public class CategoryServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		try {
			PrintWriter out=response.getWriter();
			HttpSession session=request.getSession();
			DMartService dmartsevice = new DMartServiceImpl();
			List<Category> plist=dmartsevice.getCategory();
			session.setAttribute("clist", plist);
			out.println("<h3>Welcome "+session.getAttribute("username")+"</h3>");
			out.println("<center>");
			out.println("<form action='home.jsp'>");
			out.println("<select name='cat'>");
			for(Category cs : plist)
			{
				out.println("<option name='cat' value='"+cs.getCid()+"'>"+cs.getCname()+"</option>");
			}
			out.println("</select>");
			out.println("<input type='submit' name='btn' value='submit'>");
			out.println("</form>");
			out.println("</center>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
