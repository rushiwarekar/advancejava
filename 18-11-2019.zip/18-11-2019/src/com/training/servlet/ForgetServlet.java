package com.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.service.DMartService;
import com.training.service.DMartServiceImpl;

public class ForgetServlet extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException
	{
		PrintWriter out=response.getWriter();
		DMartService dmartsevice = new DMartServiceImpl();
		response.setContentType("text/html");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("cpassword");
		if(password.equals(cpassword))
		{
			int validate = dmartsevice.updatePassword(username,password);
			if(validate>0)
			{
				out.println("password change successfully");
				out.println("login with new credentials...");
				RequestDispatcher rd = request.getRequestDispatcher("Login.html");
				rd.include(request, response);
				
			}
		}
		else
		{
			out.println("please enter correct credentials...");
			RequestDispatcher rd = request.getRequestDispatcher("forgot.html");
			rd.include(request, response);
		}
		
	}

}
