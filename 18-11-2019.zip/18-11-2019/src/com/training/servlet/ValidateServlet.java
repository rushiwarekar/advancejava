package com.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.training.service.DMartService;
import com.training.service.DMartServiceImpl;

public class ValidateServlet extends HttpServlet{

	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException
	{
		PrintWriter out=response.getWriter();
		DMartService dmartsevice = new DMartServiceImpl();
		response.setContentType("text/html");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		boolean validate = dmartsevice.validateUser(username,password);
		System.out.println(validate);
		if(validate)
		{
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
			RequestDispatcher rd = request.getRequestDispatcher("category");
			rd.forward(request, response);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("Login.html");
			out.println("login not success");
			rd.include(request, response);
		}
	}
}
